import React from 'react';
import './ExchangeRate.css';
import {CurrencyBtn, DateBtn, SearchBtn} from '../../components/Buttons/Buttons';
import CurrencyList from '../../components/FullTable/FullTable';
import CustomCurrencyList from '../../components/CustomTable/CustomTable';
import moment from 'moment';

class ExchangeRate extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            ratesTable: [],
            valueStart: moment(),
            valueEnd: moment(),
            chosenCurrency: '',
            ratesTable2: [],
            codeName: '',
            currencyName: '',
        };

        this.handleChangeStart = this.handleChangeStart.bind(this);
        this.handleChangeEnd = this.handleChangeEnd.bind(this);
        this.handleChangeCurrency = this.handleChangeCurrency.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.validateForm = this.validateForm.bind(this);
    }

    componentDidMount() {
        fetch(`http://api.nbp.pl/api/exchangerates/tables/c/today/?format=json`)
            .then(data => data.json())
            .then(data => {
                this.setState({
                    ...this.state,
                    ratesTable: data[0].rates
                })
            })
            .catch(error => console.error('Error:', error))
            /* add some universal code to finally response */
            .finally(response => console.log('finally full table response', response));
    }

    handleChangeCurrency(chosenCurrency2) {
        this.setState({
            ...this.state,
            chosenCurrency: chosenCurrency2,
        })
    }

    handleChangeStart(value) {
        this.setState({
            ...this.state,
            valueStart: value
        });
    }

    handleChangeEnd(value) {
        this.setState({
            ...this.state,
            valueEnd: value
        });
    }

    validateForm() {

        if (this.state.chosenCurrency.toString().length !== 3) {
            alert('Currency MUST be chosen');
        }

        if (this.state.valueStart > moment()) {
            this.state.valueStart = moment();
            alert(`start value MUSTN'T be set as a future date`);
        }

        if (this.state.valueEnd > moment()) {
            this.state.valueEnd = moment();
            alert(`end value MUSTN'T be set as a future date`);
        }

        /* I know it looks horrible */
        /* not working properly */
        if (this.state.valueStart.toString().charAt(0) <= this.state.valueEnd.toString().charAt(0)) {
            alert('Start date value MUST be earlier than end date!');
            return false;
            if (this.state.valueStart.toString().charAt(1) <= this.state.valueEnd.toString().charAt(1)) {
                alert('Start date value MUST be earlier than end date!');
                return false;
                if (this.state.valueStart.toString().charAt(2) <= this.state.valueEnd.toString().charAt(2)) {
                    alert('Start date value MUST be earlier than end date!');
                    return false;
                    if (this.state.valueStart.toString().charAt(3) <= this.state.valueEnd.toString().charAt(3)) {
                        alert('Start date value MUST be earlier than end date!');
                        return false;
                        if (this.state.valueStart.toString().charAt(4) <= this.state.valueEnd.toString().charAt(4)) {
                            alert('Start date value MUST be earlier than end date!');
                            return false;
                            if (this.state.valueStart.toString().charAt(5) <= this.state.valueEnd.toString().charAt(5)) {
                                alert('Start date value MUST be earlier than end date!');
                                return false;
                                if (this.state.valueStart.toString().charAt(6) <= this.state.valueEnd.toString().charAt(6)) {
                                    alert('Start date value MUST be earlier than end date!');
                                    return false;
                                    if (this.state.valueStart.toString().charAt(7) <= this.state.valueEnd.toString().charAt(7)) {
                                        alert('Start date value MUST be earlier than end date!');
                                        return false;
                                        if (this.state.valueStart.toString().charAt(8) <= this.state.valueEnd.toString().charAt(8)) {
                                            alert('Start date value MUST be earlier than end date!');
                                            return false;
                                        }
                                        else {
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    handleSubmit(event) {

        event.preventDefault();
        this.validateForm();
        let startDataSec = this.state.valueStart.toJSON().slice(0, -14);
        let endDataSec = this.state.valueEnd.toJSON().slice(0, -14);
        alert(`Given data has been submitted: ${this.state.chosenCurrency} ${this.state.valueStart} ${ this.state.valueEnd}`);
        event.preventDefault();
        fetch(`http://api.nbp.pl/api/exchangerates/rates/c/${this.state.chosenCurrency}/${startDataSec}/${endDataSec}/?format=json`)
            .then(data => data.json())
            .then(data => {
                this.setState({
                    ...this.state,
                    ratesTable2: data.rates,
                    codeName: data.code,
                    currencyName: data.currency,
                });
            })
            .catch(error => console.error('Error:', error))
            /* add some universal code to finally response */
            .finally(response => console.log('finally custom table response', response));
    }


    render() {
        return (
            <div>
                <form className="buttons" onSubmit={this.handleSubmit}>
                    <CurrencyBtn
                        ratesTable={this.state.ratesTable}
                        chosenCurrency={this.state.chosenCurrency}
                        onChange={this.handleChangeCurrency}
                    />
                    <DateBtn
                        name={"Start date:"}
                        value={this.state.valueStart}
                        onChange={this.handleChangeStart}
                    />
                    <DateBtn
                        name={"End date:"}
                        value={this.state.valueEnd}
                        onChange={this.handleChangeEnd}
                    />
                    <SearchBtn
                        onSubmit={this.handleSubmit}
                    />
                </form>
                <div className="container">
                    <CurrencyList ratesTable={this.state.ratesTable}/>
                    <CustomCurrencyList
                        startDate={this.state.valueStart}
                        endDate={this.state.valueEnd}
                        chosenCurrency={this.state.chosenCurrency}
                        ratesTable2={this.state.ratesTable2}
                        codeName={this.state.codeName}
                        currencyName={this.state.currencyName}
                    />
                    {/* {
                        this.state.ratesTable.length && <CustomCurrencyList
                            startDate={this.state.valueStart}
                            endDate={this.state.valueEnd}
                            chosenCurrency={this.state.chosenCurrency}   
                        />
                    } */}
                </div>
            </div>
        )
    }

}

export default ExchangeRate;