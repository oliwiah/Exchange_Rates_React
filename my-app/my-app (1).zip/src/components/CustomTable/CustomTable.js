import React from 'react';
import './CustomTable.css';

const ChosenCurrency = (props) => {

    return (
        <tr className="table-data">
            <td className="table-cell">{props.currencyName}</td>
            <td className="table-cell">{props.codeName}</td>
            <td className="table-cell">{props.bid.toFixed(2)}</td>
            <td className="table-cell">{props.ask.toFixed(2)}</td>
            <td className="table-cell">{props.effectiveDate}</td>
        </tr>
    );
};

const CustomCurrencyList = (props) => {

        return (
            <table>
                <tbody>
                    <tr>
                        <th scope="col" rowSpan="2">Currency</th>
                        <th scope="col" rowSpan="2">Code</th>
                        <th scope="col" colSpan="2">Rate</th>
                        <th scope="col" rowSpan="2">Date</th>
                    </tr>
                    <tr className="lighter-header">
                        <th scope="col" className="brd">Buy</th>
                        <th scope="col">Sell</th>
                    </tr>
                    {props.ratesTable2.map(selectedCurrency => <ChosenCurrency key={selectedCurrency.no + selectedCurrency.bid + selectedCurrency.ask}
                                                                                    {...selectedCurrency}
                                                                                    currencyName={props.currencyName}
                                                                                    codeName={props.codeName}
                                                                     />)}
                    {
                        !props.ratesTable2.length && <tr><td scope="col" colSpan="5">Waiting for your input...</td></tr>
                    }
                </tbody>
            </table>
        );
};

export default CustomCurrencyList;