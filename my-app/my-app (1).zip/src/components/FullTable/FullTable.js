import React from 'react';
import './FullTable.css';

const SingleCurrency = (props) => {
    return (
        <tr className="table-data">
            <td className="table-cell">{props.currency}</td>
            <td className="table-cell">{props.code}</td>
            <td className="table-cell">{props.bid.toFixed(2)}</td>
            <td className="table-cell">{props.ask.toFixed(2)}</td>
        </tr>
    )
};

const CurrencyList = (props) => {

        return (
            <table>
                <tbody>
                    <tr>
                        <th scope="col" rowSpan="2">Currency</th>
                        <th scope="col" rowSpan="2">Code</th>
                        <th scope="col" colSpan="2">Rate</th>
                    </tr>
                    <tr>
                        <th scope="col" className="brd">Buy</th>
                        <th scope="col">Sell</th>
                    </tr>
                    {props.ratesTable.map(singleCurrency => <SingleCurrency key={singleCurrency.code + singleCurrency.ask + singleCurrency.bid} {...singleCurrency} />)}
                </tbody>
            </table>
        );
    };

export default CurrencyList;