import React from 'react';
import './Header.css';
import Clock from 'react-live-clock';
import Time from 'react-time'

class MyData extends React.Component {
    render() {
        let now = new Date()
        return (
            <p>
                <Time value={now} format="YYYY/MM/DD" />
            </p>
        )
    }
 }

const Header = () => (
    <div className="header fade-in-animation">
        <p className="title">
            Exchange Rate
        </p>
        <div className="data">
            <MyData />
            <Clock format={'HH:mm:ss'} ticking={true} timezone={'Europe/Berlin'}/>
        </div>
    </div>
)


   
export default Header;